<?php
$type='Type1';
$name='DejaVuSans';
$desc=array('Ascent'=>928,'Descent'=>-236,'CapHeight'=>729,'Flags'=>32,'FontBBox'=>'[-52 -236 956 928]','ItalicAngle'=>0,'StemV'=>70,'MissingWidth'=>600);
$up=-42;
$ut=44;
$cw=array(
	chr(0)=>600,chr(1)=>600,chr(2)=>600,chr(3)=>600,chr(4)=>600,chr(5)=>600,chr(6)=>600,chr(7)=>600,chr(8)=>600,chr(9)=>600,chr(10)=>600,chr(11)=>600,chr(12)=>600,chr(13)=>600,chr(14)=>600,chr(15)=>600,chr(16)=>600,chr(17)=>600,chr(18)=>600,chr(19)=>600,chr(20)=>600,chr(21)=>600,
	chr(22)=>600,chr(23)=>600,chr(24)=>600,chr(25)=>600,chr(26)=>600,chr(27)=>600,chr(28)=>600,chr(29)=>600,chr(30)=>600,chr(31)=>600,' '=>636,'!'=>401,'"'=>460,'#'=>838,'$'=>636,'%'=>950,'&'=>780,'\''=>275,'('=>390,')'=>390,'*'=>500,'+'=>838,
	','=>318,'-'=>361,'.'=>318,'/'=>337,'0'=>636,'1'=>636,'2'=>636,'3'=>636,'4'=>636,'5'=>636,'6'=>636,'7'=>636,'8'=>636,'9'=>636,':'=>337,';'=>337,'<'=>838,'='=>838,'>'=>838,'?'=>531,'@'=>1000,'A'=>684,
	'B'=>686,'C'=>698,'D'=>770,'E'=>632,'F'=>575,'G'=>775,'H'=>752,'I'=>295,'J'=>295,'K'=>656,'L'=>557,'M'=>863,'N'=>748,'O'=>787,'P'=>603,'Q'=>787,'R'=>695,'S'=>635,'T'=>611,'U'=>732,'V'=>684,'W'=>989,
	'X'=>685,'Y'=>611,'Z'=>685,'['=>390,'\\'=>337,']'=>390,'^'=>838,'_'=>500,'`'=>500,'a'=>613,'b'=>635,'c'=>550,'d'=>635,'e'=>615,'f'=>352,'g'=>635,'h'=>634,'i'=>278,'j'=>278,'k'=>579,'l'=>278,'m'=>974,
	'n'=>634,'o'=>612,'p'=>635,'q'=>635,'r'=>411,'s'=>521,'t'=>392,'u'=>634,'v'=>592,'w'=>818,'x'=>592,'y'=>592,'z'=>525,'{'=>636,'|'=>337,'}'=>636,'~'=>838,chr(127)=>600,chr(128)=>600,chr(129)=>600,chr(130)=>600,chr(131)=>600,
	chr(132)=>600,chr(133)=>600,chr(134)=>600,chr(135)=>600,chr(136)=>600,chr(137)=>600,chr(138)=>600,chr(139)=>600,chr(140)=>600,chr(141)=>600,chr(142)=>600,chr(143)=>600,chr(144)=>600,chr(145)=>600,chr(146)=>600,chr(147)=>600,chr(148)=>600,chr(149)=>600,chr(150)=>600,chr(151)=>600,chr(152)=>600,chr(153)=>600,
	chr(154)=>600,chr(155)=>600,chr(156)=>600,chr(157)=>600,chr(158)=>600,chr(159)=>600,chr(160)=>636,chr(161)=>684,chr(162)=>600,chr(163)=>562,chr(164)=>600,chr(165)=>600,chr(166)=>635,chr(167)=>500,chr(168)=>500,chr(169)=>600,chr(170)=>600,chr(171)=>600,chr(172)=>685,chr(173)=>361,chr(174)=>600,chr(175)=>685,
	chr(176)=>500,chr(177)=>613,chr(178)=>500,chr(179)=>284,chr(180)=>500,chr(181)=>600,chr(182)=>521,chr(183)=>600,chr(184)=>600,chr(185)=>600,chr(186)=>600,chr(187)=>600,chr(188)=>525,chr(189)=>600,chr(190)=>600,chr(191)=>525,chr(192)=>600,chr(193)=>600,chr(194)=>600,chr(195)=>600,chr(196)=>600,chr(197)=>600,
	chr(198)=>698,chr(199)=>600,chr(200)=>600,chr(201)=>600,chr(202)=>632,chr(203)=>600,chr(204)=>600,chr(205)=>600,chr(206)=>600,chr(207)=>600,chr(208)=>600,chr(209)=>748,chr(210)=>600,chr(211)=>787,chr(212)=>600,chr(213)=>600,chr(214)=>600,chr(215)=>838,chr(216)=>600,chr(217)=>600,chr(218)=>600,chr(219)=>600,
	chr(220)=>600,chr(221)=>600,chr(222)=>600,chr(223)=>600,chr(224)=>600,chr(225)=>600,chr(226)=>600,chr(227)=>600,chr(228)=>600,chr(229)=>600,chr(230)=>550,chr(231)=>600,chr(232)=>600,chr(233)=>600,chr(234)=>615,chr(235)=>600,chr(236)=>600,chr(237)=>600,chr(238)=>600,chr(239)=>600,chr(240)=>600,chr(241)=>634,
	chr(242)=>600,chr(243)=>612,chr(244)=>600,chr(245)=>600,chr(246)=>600,chr(247)=>838,chr(248)=>600,chr(249)=>600,chr(250)=>600,chr(251)=>600,chr(252)=>600,chr(253)=>600,chr(254)=>600,chr(255)=>500);
$enc='iso-8859-2';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /Aogonek /.notdef /Lslash /.notdef /.notdef /Sacute 169 /.notdef /.notdef /.notdef /Zacute 174 /.notdef /Zdotaccent 177 /aogonek /ogonek /lslash 181 /.notdef /sacute /.notdef /.notdef /.notdef /.notdef /.notdef /zacute /.notdef /.notdef /zdotaccent /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /Cacute /.notdef /.notdef /.notdef /Eogonek /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /Nacute /.notdef 212 /.notdef /.notdef /.notdef 216 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /cacute /.notdef /.notdef /.notdef /eogonek /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /nacute /.notdef 244 /.notdef /.notdef /.notdef 248 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /dotaccent';
$file='DejaVuSans.z';
$size1=5971;
$size2=25787;
?>
