<?php
$type='Type1';
$name='DejaVuSerifCondensed-BoldOblique';
$desc=array('Ascent'=>939,'Descent'=>-236,'CapHeight'=>729,'Flags'=>96,'FontBBox'=>'[-149 -236 1085 952]','ItalicAngle'=>-11,'StemV'=>120,'MissingWidth'=>540);
$up=-42;
$ut=44;
$cw=array(
	chr(0)=>540,chr(1)=>540,chr(2)=>540,chr(3)=>540,chr(4)=>540,chr(5)=>540,chr(6)=>540,chr(7)=>540,chr(8)=>540,chr(9)=>540,chr(10)=>540,chr(11)=>540,chr(12)=>540,chr(13)=>540,chr(14)=>540,chr(15)=>540,chr(16)=>540,chr(17)=>540,chr(18)=>540,chr(19)=>540,chr(20)=>540,chr(21)=>540,
	chr(22)=>540,chr(23)=>540,chr(24)=>540,chr(25)=>540,chr(26)=>540,chr(27)=>540,chr(28)=>540,chr(29)=>540,chr(30)=>540,chr(31)=>540,' '=>626,'!'=>395,'"'=>469,'#'=>754,'$'=>626,'%'=>855,'&'=>813,'\''=>275,'('=>426,')'=>426,'*'=>470,'+'=>754,
	','=>313,'-'=>374,'.'=>313,'/'=>329,'0'=>626,'1'=>626,'2'=>626,'3'=>626,'4'=>626,'5'=>626,'6'=>626,'7'=>626,'8'=>626,'9'=>626,':'=>332,';'=>332,'<'=>754,'='=>754,'>'=>754,'?'=>527,'@'=>900,'A'=>698,
	'B'=>760,'C'=>716,'D'=>780,'E'=>686,'F'=>639,'G'=>769,'H'=>850,'I'=>421,'J'=>426,'K'=>782,'L'=>633,'M'=>996,'N'=>822,'O'=>784,'P'=>677,'Q'=>784,'R'=>748,'S'=>650,'T'=>669,'U'=>785,'V'=>698,'W'=>1011,
	'X'=>698,'Y'=>642,'Z'=>657,'['=>426,'\\'=>329,']'=>426,'^'=>754,'_'=>450,'`'=>450,'a'=>583,'b'=>629,'c'=>548,'d'=>629,'e'=>572,'f'=>387,'g'=>629,'h'=>654,'i'=>342,'j'=>325,'k'=>624,'l'=>342,'m'=>952,
	'n'=>654,'o'=>600,'p'=>629,'q'=>629,'r'=>474,'s'=>506,'t'=>416,'u'=>654,'v'=>523,'w'=>774,'x'=>536,'y'=>523,'z'=>511,'{'=>579,'|'=>327,'}'=>579,'~'=>754,chr(127)=>540,chr(128)=>540,chr(129)=>540,chr(130)=>540,chr(131)=>540,
	chr(132)=>540,chr(133)=>540,chr(134)=>540,chr(135)=>540,chr(136)=>540,chr(137)=>540,chr(138)=>540,chr(139)=>540,chr(140)=>540,chr(141)=>540,chr(142)=>540,chr(143)=>540,chr(144)=>540,chr(145)=>540,chr(146)=>540,chr(147)=>540,chr(148)=>540,chr(149)=>540,chr(150)=>540,chr(151)=>540,chr(152)=>540,chr(153)=>540,
	chr(154)=>540,chr(155)=>540,chr(156)=>540,chr(157)=>540,chr(158)=>540,chr(159)=>540,chr(160)=>626,chr(161)=>698,chr(162)=>540,chr(163)=>639,chr(164)=>540,chr(165)=>540,chr(166)=>650,chr(167)=>470,chr(168)=>450,chr(169)=>540,chr(170)=>540,chr(171)=>540,chr(172)=>657,chr(173)=>374,chr(174)=>540,chr(175)=>657,
	chr(176)=>450,chr(177)=>583,chr(178)=>450,chr(179)=>346,chr(180)=>450,chr(181)=>540,chr(182)=>506,chr(183)=>540,chr(184)=>540,chr(185)=>540,chr(186)=>540,chr(187)=>540,chr(188)=>511,chr(189)=>540,chr(190)=>540,chr(191)=>511,chr(192)=>540,chr(193)=>540,chr(194)=>540,chr(195)=>540,chr(196)=>540,chr(197)=>540,
	chr(198)=>716,chr(199)=>540,chr(200)=>540,chr(201)=>540,chr(202)=>686,chr(203)=>540,chr(204)=>540,chr(205)=>540,chr(206)=>540,chr(207)=>540,chr(208)=>540,chr(209)=>822,chr(210)=>540,chr(211)=>784,chr(212)=>540,chr(213)=>540,chr(214)=>540,chr(215)=>754,chr(216)=>540,chr(217)=>540,chr(218)=>540,chr(219)=>540,
	chr(220)=>540,chr(221)=>540,chr(222)=>540,chr(223)=>540,chr(224)=>540,chr(225)=>540,chr(226)=>540,chr(227)=>540,chr(228)=>540,chr(229)=>540,chr(230)=>548,chr(231)=>540,chr(232)=>540,chr(233)=>540,chr(234)=>572,chr(235)=>540,chr(236)=>540,chr(237)=>540,chr(238)=>540,chr(239)=>540,chr(240)=>540,chr(241)=>654,
	chr(242)=>540,chr(243)=>600,chr(244)=>540,chr(245)=>540,chr(246)=>540,chr(247)=>754,chr(248)=>540,chr(249)=>540,chr(250)=>540,chr(251)=>540,chr(252)=>540,chr(253)=>540,chr(254)=>540,chr(255)=>450);
$enc='iso-8859-2';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /Aogonek /.notdef /Lslash /.notdef /.notdef /Sacute 169 /.notdef /.notdef /.notdef /Zacute 174 /.notdef /Zdotaccent 177 /aogonek /ogonek /lslash 181 /.notdef /sacute /.notdef /.notdef /.notdef /.notdef /.notdef /zacute /.notdef /.notdef /zdotaccent /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /Cacute /.notdef /.notdef /.notdef /Eogonek /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /Nacute /.notdef 212 /.notdef /.notdef /.notdef 216 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /cacute /.notdef /.notdef /.notdef /eogonek /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /nacute /.notdef 244 /.notdef /.notdef /.notdef 248 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /dotaccent';
$file='DejaVuSerifCondensed-BoldOblique.z';
$size1=5970;
$size2=30149;
?>
