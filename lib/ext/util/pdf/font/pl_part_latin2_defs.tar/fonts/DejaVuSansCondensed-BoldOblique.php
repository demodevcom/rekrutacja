<?php
$type='Type1';
$name='DejaVuSansCondensed-BoldOblique';
$desc=array('Ascent'=>928,'Descent'=>-236,'CapHeight'=>729,'Flags'=>96,'FontBBox'=>'[-149 -236 1029 928]','ItalicAngle'=>-11,'StemV'=>120,'MissingWidth'=>540);
$up=-42;
$ut=44;
$cw=array(
	chr(0)=>540,chr(1)=>540,chr(2)=>540,chr(3)=>540,chr(4)=>540,chr(5)=>540,chr(6)=>540,chr(7)=>540,chr(8)=>540,chr(9)=>540,chr(10)=>540,chr(11)=>540,chr(12)=>540,chr(13)=>540,chr(14)=>540,chr(15)=>540,chr(16)=>540,chr(17)=>540,chr(18)=>540,chr(19)=>540,chr(20)=>540,chr(21)=>540,
	chr(22)=>540,chr(23)=>540,chr(24)=>540,chr(25)=>540,chr(26)=>540,chr(27)=>540,chr(28)=>540,chr(29)=>540,chr(30)=>540,chr(31)=>540,' '=>626,'!'=>410,'"'=>469,'#'=>626,'$'=>626,'%'=>901,'&'=>785,'\''=>275,'('=>411,')'=>411,'*'=>470,'+'=>754,
	','=>342,'-'=>374,'.'=>342,'/'=>329,'0'=>626,'1'=>626,'2'=>626,'3'=>626,'4'=>626,'5'=>626,'6'=>626,'7'=>626,'8'=>626,'9'=>626,':'=>360,';'=>360,'<'=>754,'='=>754,'>'=>754,'?'=>522,'@'=>900,'A'=>696,
	'B'=>686,'C'=>660,'D'=>747,'E'=>615,'F'=>615,'G'=>738,'H'=>753,'I'=>334,'J'=>334,'K'=>697,'L'=>573,'M'=>896,'N'=>753,'O'=>765,'P'=>659,'Q'=>765,'R'=>693,'S'=>648,'T'=>614,'U'=>730,'V'=>696,'W'=>993,
	'X'=>694,'Y'=>651,'Z'=>652,'['=>411,'\\'=>329,']'=>411,'^'=>754,'_'=>450,'`'=>450,'a'=>607,'b'=>644,'c'=>533,'d'=>644,'e'=>610,'f'=>391,'g'=>644,'h'=>641,'i'=>308,'j'=>308,'k'=>598,'l'=>308,'m'=>938,
	'n'=>641,'o'=>618,'p'=>644,'q'=>644,'r'=>444,'s'=>536,'t'=>430,'u'=>641,'v'=>586,'w'=>831,'x'=>580,'y'=>586,'z'=>523,'{'=>641,'|'=>329,'}'=>641,'~'=>754,chr(127)=>540,chr(128)=>540,chr(129)=>540,chr(130)=>540,chr(131)=>540,
	chr(132)=>540,chr(133)=>540,chr(134)=>540,chr(135)=>540,chr(136)=>540,chr(137)=>540,chr(138)=>540,chr(139)=>540,chr(140)=>540,chr(141)=>540,chr(142)=>540,chr(143)=>540,chr(144)=>540,chr(145)=>540,chr(146)=>540,chr(147)=>540,chr(148)=>540,chr(149)=>540,chr(150)=>540,chr(151)=>540,chr(152)=>540,chr(153)=>540,
	chr(154)=>540,chr(155)=>540,chr(156)=>540,chr(157)=>540,chr(158)=>540,chr(159)=>540,chr(160)=>626,chr(161)=>696,chr(162)=>540,chr(163)=>594,chr(164)=>540,chr(165)=>540,chr(166)=>648,chr(167)=>450,chr(168)=>450,chr(169)=>540,chr(170)=>540,chr(171)=>540,chr(172)=>652,chr(173)=>374,chr(174)=>540,chr(175)=>652,
	chr(176)=>450,chr(177)=>607,chr(178)=>450,chr(179)=>337,chr(180)=>450,chr(181)=>540,chr(182)=>536,chr(183)=>540,chr(184)=>540,chr(185)=>540,chr(186)=>540,chr(187)=>540,chr(188)=>523,chr(189)=>540,chr(190)=>540,chr(191)=>523,chr(192)=>540,chr(193)=>540,chr(194)=>540,chr(195)=>540,chr(196)=>540,chr(197)=>540,
	chr(198)=>660,chr(199)=>540,chr(200)=>540,chr(201)=>540,chr(202)=>615,chr(203)=>540,chr(204)=>540,chr(205)=>540,chr(206)=>540,chr(207)=>540,chr(208)=>540,chr(209)=>753,chr(210)=>540,chr(211)=>765,chr(212)=>540,chr(213)=>540,chr(214)=>540,chr(215)=>754,chr(216)=>540,chr(217)=>540,chr(218)=>540,chr(219)=>540,
	chr(220)=>540,chr(221)=>540,chr(222)=>540,chr(223)=>540,chr(224)=>540,chr(225)=>540,chr(226)=>540,chr(227)=>540,chr(228)=>540,chr(229)=>540,chr(230)=>533,chr(231)=>540,chr(232)=>540,chr(233)=>540,chr(234)=>610,chr(235)=>540,chr(236)=>540,chr(237)=>540,chr(238)=>540,chr(239)=>540,chr(240)=>540,chr(241)=>641,
	chr(242)=>540,chr(243)=>618,chr(244)=>540,chr(245)=>540,chr(246)=>540,chr(247)=>754,chr(248)=>540,chr(249)=>540,chr(250)=>540,chr(251)=>540,chr(252)=>540,chr(253)=>540,chr(254)=>540,chr(255)=>450);
$enc='iso-8859-2';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /Aogonek /.notdef /Lslash /.notdef /.notdef /Sacute 169 /.notdef /.notdef /.notdef /Zacute 174 /.notdef /Zdotaccent 177 /aogonek /ogonek /lslash 181 /.notdef /sacute /.notdef /.notdef /.notdef /.notdef /.notdef /zacute /.notdef /.notdef /zdotaccent /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /Cacute /.notdef /.notdef /.notdef /Eogonek /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /Nacute /.notdef 212 /.notdef /.notdef /.notdef 216 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /cacute /.notdef /.notdef /.notdef /eogonek /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /nacute /.notdef 244 /.notdef /.notdef /.notdef 248 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /dotaccent';
$file='DejaVuSansCondensed-BoldOblique.z';
$size1=6079;
$size2=25876;
?>
