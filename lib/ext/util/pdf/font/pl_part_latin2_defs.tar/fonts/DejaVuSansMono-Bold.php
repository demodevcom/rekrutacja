<?php
$type='Type1';
$name='DejaVuSansMono-Bold';
$desc=array('Ascent'=>928,'Descent'=>-236,'CapHeight'=>729,'Flags'=>33,'FontBBox'=>'[-19 -236 603 952]','ItalicAngle'=>0,'StemV'=>120,'MissingWidth'=>602);
$up=-42;
$ut=44;
$cw=array(
	chr(0)=>602,chr(1)=>602,chr(2)=>602,chr(3)=>602,chr(4)=>602,chr(5)=>602,chr(6)=>602,chr(7)=>602,chr(8)=>602,chr(9)=>602,chr(10)=>602,chr(11)=>602,chr(12)=>602,chr(13)=>602,chr(14)=>602,chr(15)=>602,chr(16)=>602,chr(17)=>602,chr(18)=>602,chr(19)=>602,chr(20)=>602,chr(21)=>602,
	chr(22)=>602,chr(23)=>602,chr(24)=>602,chr(25)=>602,chr(26)=>602,chr(27)=>602,chr(28)=>602,chr(29)=>602,chr(30)=>602,chr(31)=>602,' '=>602,'!'=>602,'"'=>602,'#'=>602,'$'=>602,'%'=>602,'&'=>602,'\''=>602,'('=>602,')'=>602,'*'=>602,'+'=>602,
	','=>602,'-'=>602,'.'=>602,'/'=>602,'0'=>602,'1'=>602,'2'=>602,'3'=>602,'4'=>602,'5'=>602,'6'=>602,'7'=>602,'8'=>602,'9'=>602,':'=>602,';'=>602,'<'=>602,'='=>602,'>'=>602,'?'=>602,'@'=>602,'A'=>602,
	'B'=>602,'C'=>602,'D'=>602,'E'=>602,'F'=>602,'G'=>602,'H'=>602,'I'=>602,'J'=>602,'K'=>602,'L'=>602,'M'=>602,'N'=>602,'O'=>602,'P'=>602,'Q'=>602,'R'=>602,'S'=>602,'T'=>602,'U'=>602,'V'=>602,'W'=>602,
	'X'=>602,'Y'=>602,'Z'=>602,'['=>602,'\\'=>602,']'=>602,'^'=>602,'_'=>602,'`'=>602,'a'=>602,'b'=>602,'c'=>602,'d'=>602,'e'=>602,'f'=>602,'g'=>602,'h'=>602,'i'=>602,'j'=>602,'k'=>602,'l'=>602,'m'=>602,
	'n'=>602,'o'=>602,'p'=>602,'q'=>602,'r'=>602,'s'=>602,'t'=>602,'u'=>602,'v'=>602,'w'=>602,'x'=>602,'y'=>602,'z'=>602,'{'=>602,'|'=>602,'}'=>602,'~'=>602,chr(127)=>602,chr(128)=>602,chr(129)=>602,chr(130)=>602,chr(131)=>602,
	chr(132)=>602,chr(133)=>602,chr(134)=>602,chr(135)=>602,chr(136)=>602,chr(137)=>602,chr(138)=>602,chr(139)=>602,chr(140)=>602,chr(141)=>602,chr(142)=>602,chr(143)=>602,chr(144)=>602,chr(145)=>602,chr(146)=>602,chr(147)=>602,chr(148)=>602,chr(149)=>602,chr(150)=>602,chr(151)=>602,chr(152)=>602,chr(153)=>602,
	chr(154)=>602,chr(155)=>602,chr(156)=>602,chr(157)=>602,chr(158)=>602,chr(159)=>602,chr(160)=>602,chr(161)=>602,chr(162)=>602,chr(163)=>602,chr(164)=>602,chr(165)=>602,chr(166)=>602,chr(167)=>602,chr(168)=>602,chr(169)=>602,chr(170)=>602,chr(171)=>602,chr(172)=>602,chr(173)=>602,chr(174)=>602,chr(175)=>602,
	chr(176)=>602,chr(177)=>602,chr(178)=>602,chr(179)=>602,chr(180)=>602,chr(181)=>602,chr(182)=>602,chr(183)=>602,chr(184)=>602,chr(185)=>602,chr(186)=>602,chr(187)=>602,chr(188)=>602,chr(189)=>602,chr(190)=>602,chr(191)=>602,chr(192)=>602,chr(193)=>602,chr(194)=>602,chr(195)=>602,chr(196)=>602,chr(197)=>602,
	chr(198)=>602,chr(199)=>602,chr(200)=>602,chr(201)=>602,chr(202)=>602,chr(203)=>602,chr(204)=>602,chr(205)=>602,chr(206)=>602,chr(207)=>602,chr(208)=>602,chr(209)=>602,chr(210)=>602,chr(211)=>602,chr(212)=>602,chr(213)=>602,chr(214)=>602,chr(215)=>602,chr(216)=>602,chr(217)=>602,chr(218)=>602,chr(219)=>602,
	chr(220)=>602,chr(221)=>602,chr(222)=>602,chr(223)=>602,chr(224)=>602,chr(225)=>602,chr(226)=>602,chr(227)=>602,chr(228)=>602,chr(229)=>602,chr(230)=>602,chr(231)=>602,chr(232)=>602,chr(233)=>602,chr(234)=>602,chr(235)=>602,chr(236)=>602,chr(237)=>602,chr(238)=>602,chr(239)=>602,chr(240)=>602,chr(241)=>602,
	chr(242)=>602,chr(243)=>602,chr(244)=>602,chr(245)=>602,chr(246)=>602,chr(247)=>602,chr(248)=>602,chr(249)=>602,chr(250)=>602,chr(251)=>602,chr(252)=>602,chr(253)=>602,chr(254)=>602,chr(255)=>602);
$enc='iso-8859-2';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /Aogonek /.notdef /Lslash /.notdef /.notdef /Sacute 169 /.notdef /.notdef /.notdef /Zacute 174 /.notdef /Zdotaccent 177 /aogonek /ogonek /lslash 181 /.notdef /sacute /.notdef /.notdef /.notdef /.notdef /.notdef /zacute /.notdef /.notdef /zdotaccent /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /Cacute /.notdef /.notdef /.notdef /Eogonek /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /Nacute /.notdef 212 /.notdef /.notdef /.notdef 216 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /cacute /.notdef /.notdef /.notdef /eogonek /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /nacute /.notdef 244 /.notdef /.notdef /.notdef 248 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /dotaccent';
$file='DejaVuSansMono-Bold.z';
$size1=5898;
$size2=28701;
?>
