<?php
$type='Type1';
$name='DejaVuSans-BoldOblique';
$desc=array('Ascent'=>928,'Descent'=>-236,'CapHeight'=>729,'Flags'=>96,'FontBBox'=>'[-166 -236 1143 928]','ItalicAngle'=>-11,'StemV'=>120,'MissingWidth'=>600);
$up=-42;
$ut=44;
$cw=array(
	chr(0)=>600,chr(1)=>600,chr(2)=>600,chr(3)=>600,chr(4)=>600,chr(5)=>600,chr(6)=>600,chr(7)=>600,chr(8)=>600,chr(9)=>600,chr(10)=>600,chr(11)=>600,chr(12)=>600,chr(13)=>600,chr(14)=>600,chr(15)=>600,chr(16)=>600,chr(17)=>600,chr(18)=>600,chr(19)=>600,chr(20)=>600,chr(21)=>600,
	chr(22)=>600,chr(23)=>600,chr(24)=>600,chr(25)=>600,chr(26)=>600,chr(27)=>600,chr(28)=>600,chr(29)=>600,chr(30)=>600,chr(31)=>600,' '=>696,'!'=>456,'"'=>521,'#'=>696,'$'=>696,'%'=>1002,'&'=>872,'\''=>306,'('=>457,')'=>457,'*'=>523,'+'=>838,
	','=>380,'-'=>415,'.'=>380,'/'=>365,'0'=>696,'1'=>696,'2'=>696,'3'=>696,'4'=>696,'5'=>696,'6'=>696,'7'=>696,'8'=>696,'9'=>696,':'=>400,';'=>400,'<'=>838,'='=>838,'>'=>838,'?'=>580,'@'=>1000,'A'=>774,
	'B'=>762,'C'=>734,'D'=>830,'E'=>683,'F'=>683,'G'=>821,'H'=>837,'I'=>372,'J'=>372,'K'=>775,'L'=>637,'M'=>995,'N'=>837,'O'=>850,'P'=>733,'Q'=>850,'R'=>770,'S'=>720,'T'=>682,'U'=>812,'V'=>774,'W'=>1103,
	'X'=>771,'Y'=>724,'Z'=>725,'['=>457,'\\'=>365,']'=>457,'^'=>838,'_'=>500,'`'=>500,'a'=>675,'b'=>716,'c'=>593,'d'=>716,'e'=>678,'f'=>435,'g'=>716,'h'=>712,'i'=>343,'j'=>343,'k'=>665,'l'=>343,'m'=>1042,
	'n'=>712,'o'=>687,'p'=>716,'q'=>716,'r'=>493,'s'=>595,'t'=>478,'u'=>712,'v'=>652,'w'=>924,'x'=>645,'y'=>652,'z'=>582,'{'=>712,'|'=>365,'}'=>712,'~'=>838,chr(127)=>600,chr(128)=>600,chr(129)=>600,chr(130)=>600,chr(131)=>600,
	chr(132)=>600,chr(133)=>600,chr(134)=>600,chr(135)=>600,chr(136)=>600,chr(137)=>600,chr(138)=>600,chr(139)=>600,chr(140)=>600,chr(141)=>600,chr(142)=>600,chr(143)=>600,chr(144)=>600,chr(145)=>600,chr(146)=>600,chr(147)=>600,chr(148)=>600,chr(149)=>600,chr(150)=>600,chr(151)=>600,chr(152)=>600,chr(153)=>600,
	chr(154)=>600,chr(155)=>600,chr(156)=>600,chr(157)=>600,chr(158)=>600,chr(159)=>600,chr(160)=>696,chr(161)=>774,chr(162)=>600,chr(163)=>660,chr(164)=>600,chr(165)=>600,chr(166)=>720,chr(167)=>500,chr(168)=>500,chr(169)=>600,chr(170)=>600,chr(171)=>600,chr(172)=>725,chr(173)=>415,chr(174)=>600,chr(175)=>725,
	chr(176)=>500,chr(177)=>675,chr(178)=>500,chr(179)=>375,chr(180)=>500,chr(181)=>600,chr(182)=>595,chr(183)=>600,chr(184)=>600,chr(185)=>600,chr(186)=>600,chr(187)=>600,chr(188)=>582,chr(189)=>600,chr(190)=>600,chr(191)=>582,chr(192)=>600,chr(193)=>600,chr(194)=>600,chr(195)=>600,chr(196)=>600,chr(197)=>600,
	chr(198)=>734,chr(199)=>600,chr(200)=>600,chr(201)=>600,chr(202)=>683,chr(203)=>600,chr(204)=>600,chr(205)=>600,chr(206)=>600,chr(207)=>600,chr(208)=>600,chr(209)=>837,chr(210)=>600,chr(211)=>850,chr(212)=>600,chr(213)=>600,chr(214)=>600,chr(215)=>838,chr(216)=>600,chr(217)=>600,chr(218)=>600,chr(219)=>600,
	chr(220)=>600,chr(221)=>600,chr(222)=>600,chr(223)=>600,chr(224)=>600,chr(225)=>600,chr(226)=>600,chr(227)=>600,chr(228)=>600,chr(229)=>600,chr(230)=>593,chr(231)=>600,chr(232)=>600,chr(233)=>600,chr(234)=>678,chr(235)=>600,chr(236)=>600,chr(237)=>600,chr(238)=>600,chr(239)=>600,chr(240)=>600,chr(241)=>712,
	chr(242)=>600,chr(243)=>687,chr(244)=>600,chr(245)=>600,chr(246)=>600,chr(247)=>838,chr(248)=>600,chr(249)=>600,chr(250)=>600,chr(251)=>600,chr(252)=>600,chr(253)=>600,chr(254)=>600,chr(255)=>500);
$enc='iso-8859-2';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /Aogonek /.notdef /Lslash /.notdef /.notdef /Sacute 169 /.notdef /.notdef /.notdef /Zacute 174 /.notdef /Zdotaccent 177 /aogonek /ogonek /lslash 181 /.notdef /sacute /.notdef /.notdef /.notdef /.notdef /.notdef /zacute /.notdef /.notdef /zdotaccent /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /Cacute /.notdef /.notdef /.notdef /Eogonek /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /Nacute /.notdef 212 /.notdef /.notdef /.notdef 216 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /cacute /.notdef /.notdef /.notdef /eogonek /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /nacute /.notdef 244 /.notdef /.notdef /.notdef 248 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /dotaccent';
$file='DejaVuSans-BoldOblique.z';
$size1=6032;
$size2=25980;
?>
