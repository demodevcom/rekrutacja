<?php
$type='Type1';
$name='DejaVuSansCondensed';
$desc=array('Ascent'=>928,'Descent'=>-236,'CapHeight'=>729,'Flags'=>32,'FontBBox'=>'[-46 -236 860 928]','ItalicAngle'=>0,'StemV'=>70,'MissingWidth'=>540);
$up=-42;
$ut=44;
$cw=array(
	chr(0)=>540,chr(1)=>540,chr(2)=>540,chr(3)=>540,chr(4)=>540,chr(5)=>540,chr(6)=>540,chr(7)=>540,chr(8)=>540,chr(9)=>540,chr(10)=>540,chr(11)=>540,chr(12)=>540,chr(13)=>540,chr(14)=>540,chr(15)=>540,chr(16)=>540,chr(17)=>540,chr(18)=>540,chr(19)=>540,chr(20)=>540,chr(21)=>540,
	chr(22)=>540,chr(23)=>540,chr(24)=>540,chr(25)=>540,chr(26)=>540,chr(27)=>540,chr(28)=>540,chr(29)=>540,chr(30)=>540,chr(31)=>540,' '=>572,'!'=>360,'"'=>414,'#'=>754,'$'=>572,'%'=>855,'&'=>702,'\''=>247,'('=>351,')'=>351,'*'=>450,'+'=>754,
	','=>286,'-'=>325,'.'=>286,'/'=>303,'0'=>572,'1'=>572,'2'=>572,'3'=>572,'4'=>572,'5'=>572,'6'=>572,'7'=>572,'8'=>572,'9'=>572,':'=>303,';'=>303,'<'=>754,'='=>754,'>'=>754,'?'=>478,'@'=>900,'A'=>615,
	'B'=>617,'C'=>628,'D'=>693,'E'=>568,'F'=>518,'G'=>697,'H'=>677,'I'=>265,'J'=>265,'K'=>590,'L'=>501,'M'=>776,'N'=>673,'O'=>708,'P'=>542,'Q'=>708,'R'=>625,'S'=>571,'T'=>549,'U'=>659,'V'=>615,'W'=>890,
	'X'=>616,'Y'=>549,'Z'=>616,'['=>351,'\\'=>303,']'=>351,'^'=>754,'_'=>450,'`'=>450,'a'=>551,'b'=>571,'c'=>495,'d'=>571,'e'=>554,'f'=>316,'g'=>571,'h'=>570,'i'=>250,'j'=>250,'k'=>521,'l'=>250,'m'=>876,
	'n'=>570,'o'=>550,'p'=>571,'q'=>571,'r'=>370,'s'=>469,'t'=>353,'u'=>570,'v'=>532,'w'=>736,'x'=>532,'y'=>532,'z'=>472,'{'=>572,'|'=>303,'}'=>572,'~'=>754,chr(127)=>540,chr(128)=>540,chr(129)=>540,chr(130)=>540,chr(131)=>540,
	chr(132)=>540,chr(133)=>540,chr(134)=>540,chr(135)=>540,chr(136)=>540,chr(137)=>540,chr(138)=>540,chr(139)=>540,chr(140)=>540,chr(141)=>540,chr(142)=>540,chr(143)=>540,chr(144)=>540,chr(145)=>540,chr(146)=>540,chr(147)=>540,chr(148)=>540,chr(149)=>540,chr(150)=>540,chr(151)=>540,chr(152)=>540,chr(153)=>540,
	chr(154)=>540,chr(155)=>540,chr(156)=>540,chr(157)=>540,chr(158)=>540,chr(159)=>540,chr(160)=>572,chr(161)=>615,chr(162)=>540,chr(163)=>505,chr(164)=>540,chr(165)=>540,chr(166)=>571,chr(167)=>450,chr(168)=>450,chr(169)=>540,chr(170)=>540,chr(171)=>540,chr(172)=>616,chr(173)=>325,chr(174)=>540,chr(175)=>616,
	chr(176)=>450,chr(177)=>551,chr(178)=>450,chr(179)=>255,chr(180)=>450,chr(181)=>540,chr(182)=>469,chr(183)=>540,chr(184)=>540,chr(185)=>540,chr(186)=>540,chr(187)=>540,chr(188)=>472,chr(189)=>540,chr(190)=>540,chr(191)=>472,chr(192)=>540,chr(193)=>540,chr(194)=>540,chr(195)=>540,chr(196)=>540,chr(197)=>540,
	chr(198)=>628,chr(199)=>540,chr(200)=>540,chr(201)=>540,chr(202)=>568,chr(203)=>540,chr(204)=>540,chr(205)=>540,chr(206)=>540,chr(207)=>540,chr(208)=>540,chr(209)=>673,chr(210)=>540,chr(211)=>708,chr(212)=>540,chr(213)=>540,chr(214)=>540,chr(215)=>754,chr(216)=>540,chr(217)=>540,chr(218)=>540,chr(219)=>540,
	chr(220)=>540,chr(221)=>540,chr(222)=>540,chr(223)=>540,chr(224)=>540,chr(225)=>540,chr(226)=>540,chr(227)=>540,chr(228)=>540,chr(229)=>540,chr(230)=>495,chr(231)=>540,chr(232)=>540,chr(233)=>540,chr(234)=>554,chr(235)=>540,chr(236)=>540,chr(237)=>540,chr(238)=>540,chr(239)=>540,chr(240)=>540,chr(241)=>570,
	chr(242)=>540,chr(243)=>550,chr(244)=>540,chr(245)=>540,chr(246)=>540,chr(247)=>754,chr(248)=>540,chr(249)=>540,chr(250)=>540,chr(251)=>540,chr(252)=>540,chr(253)=>540,chr(254)=>540,chr(255)=>450);
$enc='iso-8859-2';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /Aogonek /.notdef /Lslash /.notdef /.notdef /Sacute 169 /.notdef /.notdef /.notdef /Zacute 174 /.notdef /Zdotaccent 177 /aogonek /ogonek /lslash 181 /.notdef /sacute /.notdef /.notdef /.notdef /.notdef /.notdef /zacute /.notdef /.notdef /zdotaccent /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /Cacute /.notdef /.notdef /.notdef /Eogonek /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /Nacute /.notdef 212 /.notdef /.notdef /.notdef 216 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /cacute /.notdef /.notdef /.notdef /eogonek /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /nacute /.notdef 244 /.notdef /.notdef /.notdef 248 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /dotaccent';
$file='DejaVuSansCondensed.z';
$size1=6023;
$size2=25692;
?>
